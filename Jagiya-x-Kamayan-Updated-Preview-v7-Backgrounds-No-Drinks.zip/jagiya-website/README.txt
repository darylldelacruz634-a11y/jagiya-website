Jagiya x Kamayan website preview

Background restoration:
- Hero background restored from the original website's embedded food-table photo.
- Unlimited Samgyup section background restored from the original website's grill photo.
- Rice Meals, Korean Snacks, Pinoy Inasal, and Silog Corner section backgrounds restored from the original website's embedded food photos.
- U.Daily drinks remain removed as requested.
- Original menu-reference photos and updated menu/calculator features are retained.

Deployment:
- Keep index.html at the website root.
- Keep the assets/ folder alongside index.html.
- Upload the contents of the jagiya-website folder to Vercel.
- This is a preview build. Test interactive controls before replacing the live deployment.

Update v7: Original food photography is retained as CSS section backgrounds. Removed the drinks-related menu photo from the visible reference strip and renamed the navigation item to “Rice Meals & Snacks.” No drinks category is displayed.
